const ADMIN_EMAIL = "ugwempire@gmail.com";

const firebaseConfig = {
  apiKey: "AIzaSyAdPU62qFssdR9sQq6p-OFO_pmb4IM5CF0",
  authDomain: "nallasopara-water-update.firebaseapp.com",
  projectId: "nallasopara-water-update",
  storageBucket: "nallasopara-water-update.firebasestorage.app",
  messagingSenderId: "838883856994",
  appId: "1:838883856994:web:cf4ecfee5d4d1ce234773b",
  measurementId: "G-C1X8YYD29H",
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();
const docRef = db.collection("waterSchedule").doc("today");

const PAGE_SIZE = 10;

const loginModal = document.getElementById("loginModal");
const emailInput = document.getElementById("emailInput");
const passwordInput = document.getElementById("passwordInput");
const loginMessage = document.getElementById("loginMessage");
const submitLoginBtn = document.getElementById("submitLoginBtn");
const cancelLoginBtn = document.getElementById("cancelLoginBtn");
const scheduleBody = document.getElementById("scheduleBody");
const adminActionsHeader = document.getElementById("adminActionsHeader");
const addAreaBtn = document.getElementById("addAreaBtn");
const addAffiliateBtn = document.getElementById("addAffiliateBtn");
const affiliateLinks = document.getElementById("affiliateLinks");
const unlockBtn = document.getElementById("unlockBtn");

addAreaBtn.style.display = "none";
addAffiliateBtn.style.display = "none";
adminActionsHeader.classList.add("hidden");

let allItems = [];
let affiliateItems = [];
let currentPage = 0;

function showToast(message, type = "success") {
  let toast = document.getElementById("appToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "appToast";
    toast.style.position = "fixed";
    toast.style.bottom = "20px";
    toast.style.left = "50%";
    toast.style.transform = "translateX(-50%)";
    toast.style.padding = "10px 16px";
    toast.style.borderRadius = "10px";
    toast.style.color = "#fff";
    toast.style.zIndex = "100";
    document.body.appendChild(toast);
  }
  toast.style.background = type === "error" ? "#dc2626" : "#16a34a";
  toast.textContent = message;
  toast.style.display = "block";
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    toast.style.display = "none";
  }, 2500);
}

function showTime() {
  const now = new Date();
  document.getElementById("currentTime").textContent = now.toLocaleString();
  document.getElementById("currentDate").textContent = now.toLocaleDateString();
}

function defaultAreas() {
  return [
    { area: "किणि नगर, साई नगर", time: "" },
    { area: "हवाई पाडा", time: "" },
    { area: "भक्तीधाम", time: "" },
    { area: "लसावीर नगर", time: "" },
    { area: "धनंजय प्लॉट", time: "" },
    { area: "राशिद कंपाऊंड", time: "" },
    { area: "भारत सोसायटी सकीना चाल", time: "" },
    { area: "चौबे पान शर्मावाडी, पार्वती हॉटेल, यादव नगर, कुवेस्कर गल्ली", time: "" },
    { area: "यूपी नाका अनाडीस", time: "" },
    { area: "कारगिल नगर", time: "" },
    { area: "मंगलमूर्ती बावशेत पाडा", time: "" }
  ];
}

function defaultAffiliateItems() {
  return [
    {
      title: "Best Water Bottle",
      desc: "Useful daily product",
      url: "https://example.com",
      image: "https://via.placeholder.com/600x400?text=Product+1",
      price: "₹499",
      discount: "20% OFF"
    }
  ];
}

function getPageCount() {
  return Math.max(1, Math.ceil(allItems.length / PAGE_SIZE));
}

function syncScheduleInputs() {
  document.querySelectorAll(".schedule-input").forEach((input) => {
    const index = Number(input.dataset.index);
    const field = input.dataset.field;
    if (!allItems[index]) return;
    allItems[index][field] = input.value;
  });
}

function renderPagination() {
  let pager = document.getElementById("paginationControls");
  if (!pager) {
    pager = document.createElement("div");
    pager.id = "paginationControls";
    pager.className = "flex items-center justify-center gap-3 mt-4 mb-2";
    document.querySelector(".water-table").after(pager);
  }

  const totalPages = getPageCount();
  if (currentPage > totalPages - 1) currentPage = totalPages - 1;
  if (currentPage < 0) currentPage = 0;

  pager.innerHTML = `
    <button id="prevPageBtn" type="button" class="page-btn" ${currentPage === 0 ? "disabled" : ""}>Previous</button>
    <span class="page-info">Page ${currentPage + 1} of ${totalPages}</span>
    <button id="nextPageBtn" type="button" class="page-btn" ${currentPage >= totalPages - 1 ? "disabled" : ""}>Next</button>
  `;

  document.getElementById("prevPageBtn").onclick = () => {
    if (currentPage > 0) {
      syncScheduleInputs();
      currentPage--;
      renderSchedule();
    }
  };

  document.getElementById("nextPageBtn").onclick = () => {
    if (currentPage < totalPages - 1) {
      syncScheduleInputs();
      currentPage++;
      renderSchedule();
    }
  };
}

function renderSchedule() {
  scheduleBody.innerHTML = "";
  const start = currentPage * PAGE_SIZE;
  const pageItems = allItems.slice(start, start + PAGE_SIZE);

  pageItems.forEach((item, i) => {
    const index = start + i;
    const tr = document.createElement("tr");
    tr.className = "area-row hover:bg-light transition-colors duration-200";
    tr.innerHTML = `
      <td class="py-3 md:py-4 px-4 md:px-6 font-medium">
        <input type="text" class="area-input schedule-input" data-index="${index}" data-field="area" value="${item.area || ""}" disabled />
      </td>
      <td class="py-3 md:py-4 px-4 md:px-6">
        <input type="text" class="time-input schedule-input" data-index="${index}" data-field="time" value="${item.time || ""}" disabled />
      </td>
      <td class="py-3 md:py-4 px-4 md:px-6 text-center">
        <span class="success-badge">✓</span>
      </td>
      <td class="py-3 md:py-4 px-4 md:px-6 text-center admin-actions hidden">
        <button type="button" class="action-btn remove" data-action="remove" data-index="${index}">Remove</button>
      </td>
    `;
    scheduleBody.appendChild(tr);
  });

  renderPagination();
  setEditMode(isAdminMode());
}

function renderAffiliateLinks() {
  affiliateLinks.innerHTML = "";
  affiliateItems.forEach((item, index) => {
    const card = document.createElement("div");
    card.className = "affiliate-card";

    card.innerHTML = `
      <a href="${item.url || "#"}" target="_blank" class="block no-underline text-inherit">
        <img src="${item.image || "https://via.placeholder.com/600x400?text=Product"}" alt="${item.title || "Affiliate Product"}" class="affiliate-thumb" />
        <div class="affiliate-title">${item.title || "Product Title"}</div>
        <div class="affiliate-desc">${item.desc || "Click to view the product"}</div>
        <div class="flex items-center flex-wrap gap-2 mt-3">
          <span class="affiliate-price">${item.price || "₹499"}</span>
          <span class="affiliate-discount">${item.discount || "20% OFF"}</span>
        </div>
        <div class="affiliate-buy">Shop Now</div>
      </a>
      <div class="affiliate-remove-section hidden admin-actions mt-4 pt-3 border-t border-blue-100">
        <button type="button" class="action-btn remove w-full" data-action="remove-affiliate" data-index="${index}">Remove Product</button>
      </div>
    `;

    affiliateLinks.appendChild(card);
  });

  setEditMode(isAdminMode());
}

function isAdminMode() {
  return auth.currentUser && auth.currentUser.email === ADMIN_EMAIL;
}

function setEditMode(enabled) {
  document.querySelectorAll(".schedule-input").forEach((input) => {
    input.disabled = !enabled;
    input.style.backgroundColor = enabled ? "white" : "#f0f0f0";
    input.style.cursor = enabled ? "text" : "not-allowed";
  });

  document.querySelectorAll(".admin-actions").forEach((cell) => {
    cell.classList.toggle("hidden", !enabled);
  });

  adminActionsHeader.classList.toggle("hidden", !enabled);
  addAreaBtn.style.display = enabled ? "inline-block" : "none";
  addAffiliateBtn.style.display = enabled ? "inline-block" : "none";
}

function openLoginModal() {
  loginMessage.textContent = "";
  emailInput.value = "";
  passwordInput.value = "";
  loginModal.classList.remove("hidden");
  emailInput.focus();
}

function closeLoginModal() {
  loginModal.classList.add("hidden");
}

function updateAdminUI(isAdmin) {
  if (isAdmin) {
    unlockBtn.textContent = "Save Changes";
    unlockBtn.disabled = false;
    unlockBtn.onclick = saveAndLock;
    setEditMode(true);
  } else {
    unlockBtn.textContent = "Open Admin Panel";
    unlockBtn.disabled = false;
    unlockBtn.onclick = openLoginModal;
    setEditMode(false);
  }
}

function loadTimesLive() {
  docRef.onSnapshot((snap) => {
    const data = snap.exists ? snap.data() : {};
    allItems = Array.isArray(data.items) ? data.items : defaultAreas();
    affiliateItems = Array.isArray(data.affiliateItems) ? data.affiliateItems : defaultAffiliateItems();
    if (currentPage > getPageCount() - 1) currentPage = getPageCount() - 1;
    renderSchedule();
    renderAffiliateLinks();
  });
}

async function saveTimes() {
  await docRef.set({
    items: allItems,
    affiliateItems: affiliateItems,
    updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
    updatedBy: auth.currentUser ? auth.currentUser.email : null
  });
}

async function loginAdmin() {
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  if (!email || !password) {
    loginMessage.textContent = "Please enter email and password.";
    return;
  }

  try {
    await auth.signInWithEmailAndPassword(email, password);
    if (auth.currentUser && auth.currentUser.email === ADMIN_EMAIL) {
      closeLoginModal();
      updateAdminUI(true);
    } else {
      await auth.signOut();
      loginMessage.textContent = "Access denied. Admin only.";
    }
  } catch (error) {
    loginMessage.textContent = "Login failed. Please try again.";
  }
}

async function logoutAdmin() {
  await auth.signOut();
}

async function saveAndLock() {
  if (!auth.currentUser || auth.currentUser.email !== ADMIN_EMAIL) {
    showToast("Admin access required.", "error");
    return;
  }

  syncScheduleInputs();
  unlockBtn.disabled = true;
  unlockBtn.textContent = "Saving...";

  try {
    await saveTimes();
    await logoutAdmin();
    showToast("Changes saved successfully!", "success");
  } catch (error) {
    showToast("Failed to save changes.", "error");
  } finally {
    unlockBtn.disabled = false;
    updateAdminUI(false);
  }
}

async function addArea() {
  if (!isAdminMode()) return;
  syncScheduleInputs();
  allItems.push({ area: "New Area", time: "" });
  currentPage = getPageCount() - 1;
  renderSchedule();
  await saveTimes();
}

function readLocalImage(file) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve("");
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Unable to read image."));
    reader.readAsDataURL(file);
  });
}

function createAffiliateModal() {
  let modal = document.getElementById("affiliateModal");
  if (modal) return modal;

  modal = document.createElement("div");
  modal.id = "affiliateModal";
  modal.className = "modal hidden";
  modal.innerHTML = `
    <div class="modal-card">
      <h3 class="text-2xl font-bold mb-4 text-gray-800">Add Affiliate Link</h3>
      <input id="affiliateTitleInput" type="text" placeholder="Product title" class="modal-input" />
      <input id="affiliateDescInput" type="text" placeholder="Short description" class="modal-input" />
      <input id="affiliatePriceInput" type="text" placeholder="Price e.g. ₹499" class="modal-input" />
      <input id="affiliateDiscountInput" type="text" placeholder="Discount e.g. 20% OFF" class="modal-input" />
      <input id="affiliateUrlInput" type="url" placeholder="Affiliate URL" class="modal-input" />
      <input id="affiliateImageFileInput" type="file" accept="image/*" class="modal-input" />
      <input id="affiliateImageUrlInput" type="url" placeholder="Or image URL (optional)" class="modal-input" />
      <div class="flex gap-3 justify-end mt-5">
        <button id="cancelAffiliateBtn" type="button" class="modal-btn secondary">Cancel</button>
        <button id="saveAffiliateBtn" type="button" class="modal-btn primary">Save</button>
      </div>
      <p id="affiliateMessage" class="text-sm mt-3 text-red-600"></p>
    </div>
  `;
  document.body.appendChild(modal);

  document.getElementById("cancelAffiliateBtn").onclick = () => modal.classList.add("hidden");
  document.getElementById("saveAffiliateBtn").onclick = async () => {
    const title = document.getElementById("affiliateTitleInput").value.trim();
    const desc = document.getElementById("affiliateDescInput").value.trim();
    const price = document.getElementById("affiliatePriceInput").value.trim();
    const discount = document.getElementById("affiliateDiscountInput").value.trim();
    const url = document.getElementById("affiliateUrlInput").value.trim();
    const fileInput = document.getElementById("affiliateImageFileInput");
    const imageUrl = document.getElementById("affiliateImageUrlInput").value.trim();
    const msg = document.getElementById("affiliateMessage");

    if (!title || !url) {
      msg.textContent = "Title and URL are required.";
      return;
    }

    msg.textContent = "Loading image...";

    let image = imageUrl || "https://via.placeholder.com/600x400?text=Product";
    try {
      if (fileInput.files && fileInput.files[0]) {
        image = await readLocalImage(fileInput.files[0]);
      }
    } catch (error) {
      msg.textContent = "Image upload failed.";
      return;
    }

    affiliateItems.push({
      title,
      desc: desc || "Click to view the product",
      price: price || "₹499",
      discount: discount || "20% OFF",
      url,
      image
    });

    renderAffiliateLinks();
    await saveTimes();
    modal.classList.add("hidden");
  };

  return modal;
}

async function addAffiliate() {
  if (!isAdminMode()) return;
  const modal = createAffiliateModal();
  modal.classList.remove("hidden");
}

async function handleAffiliateRemove(index) {
  if (!isAdminMode()) return;
  affiliateItems.splice(index, 1);
  renderAffiliateLinks();
  await saveTimes();
}

document.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-action]");
  if (!btn) return;

  const action = btn.dataset.action;
  const index = Number(btn.dataset.index);

  if (action === "remove") {
    if (!isAdminMode()) return;
    syncScheduleInputs();
    allItems.splice(index, 1);
    renderSchedule();
    await saveTimes();
  }

  if (action === "remove-affiliate") {
    await handleAffiliateRemove(index);
  }
});

submitLoginBtn.onclick = loginAdmin;
cancelLoginBtn.onclick = closeLoginModal;
addAreaBtn.onclick = addArea;
addAffiliateBtn.onclick = addAffiliate;
unlockBtn.onclick = openLoginModal;

auth.onAuthStateChanged((user) => {
  updateAdminUI(!!(user && user.email === ADMIN_EMAIL));
});

loginModal.addEventListener("click", (e) => {
  if (e.target === loginModal) closeLoginModal();
});

showTime();
setInterval(showTime, 1000);
loadTimesLive();